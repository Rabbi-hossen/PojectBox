<!-- <html>
    <body>
        <title>Offer</title>
        <form action="" method="">
            <fieldset style="background-color: lightgreen;">
            <legend align="center" style="color:green" > <b > Offer!!!!!!!</b></legend>
          
            <table align="center" width=50% style="background-color: #ffffff; filter: alpha(opacity=40); opacity: 0.95;border:1px green solid;">
            <tr>
                <td>
                    <img src="anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
                <td>
                    <img src="anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
                <td>
                    <img src="anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
            </tr>
            <tr>
                <td>
                    <img src="anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
                <td>
                    <img src="anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
                <td>
                    <img src="anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
            </tr>


            </table>
            </fieldset>
        </form>
    </body>
</html> -->


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Document</title>
</head>

<body>
    <table border="1" width=70% align="center">
        <tr style="height:50px"" >
        <th width=20%> <a href=" home.php"><img src="../pic.png" alt="logo"  ></a> </th>
            <th width=60%></th>
            <th width=20%>

                <a href="login.php">Logged in as </a> |
                <a href="logout">LogOut</a>

            </th>

        </tr>

        <tr style="height:200px">
            <td  > <b>Account</b>
                <hr>
                <ul>
                    <li><a href="../dashboard.php">Dashboard</a></li>
                    <li><a href="../editprofile/editprofile.php">Edit profile</a></li>
    
                    <li><a href="../search/search.php">Search</a></li>
                    <li><a href="offer.php">Offer</a></li>
                    <li><a href="../payment/payment.php">payment</a></li>
               
                    <li><a href="logout.php">LogOut</a></li>

                </ul>

            </td>
            <td>
            <form action="" method="">
            <fieldset style="background-color: lightgreen;">
            <legend align="center" style="color:green" > <b > Offer!!!!!!!</b></legend>
          
            <table align="center" width=50% style="background-color: #ffffff; filter: alpha(opacity=40); opacity: 0.95;border:1px green solid;">
            <tr>
                <td>
                    <img src="../anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
                <td>
                <img src="../anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
                <td>
                <img src="../anniversary.png" alt="logo"> <br>

                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
            </tr>
            <tr>
                <td>
                <img src="../anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
                <td>
                <img src="../anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
                <td>
                <img src="../anniversary.png" alt="logo"> <br>
                    <b>Anniversary offer</b>
                    <p>date: 25 march</p>
                </td>
            </tr>


            </table>
            </fieldset>
        </form> 
            </td>

            <td>
                <!-- <?php

                        session_start();
                        if (isset($_SESSION['name'])) {
                            echo "<p>Welcome back," . $_SESSION['name'] . "!</p>";
                        }

                        ?>  --></p>
            </td>


        </tr>
        <tr style="height:50px">
            <td colspan=3 align="center">coppy right (C) 2017</td>
        </tr>


    </table>

</body>

</html>