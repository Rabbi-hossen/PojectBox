<?php
    $data = $_POST['data'];
    $user = json_decode($data);
 
    $data = json_encode($user);

    echo $data;
?>