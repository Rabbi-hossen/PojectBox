<html>

<body>
    <form action="signincheck.php" method="post" >
    <fieldset>
        <legend>
            Signin
        </legend>
        <table align="center" >

            <tr>
                <td>Email </td>
                <td>: <input type="email" name="email" value=""></td>
            </tr>
            <tr>
                <td>password</td>
                <td> : <input type="password" name="password" value=""> </td>
            </tr>



            <tr>

                <td>
                   <input type="submit" name="signin" value="submit">
                    <a href="signup.php">sign up</a>
                </td>
            </tr>
            <tr>
                <td>
                    <a href="Forgot password?"> Forgot password? </a>
                </td>
            </tr>
        </table>

    </fieldset>
    </form>
</body>

</html>