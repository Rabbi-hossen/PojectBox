<html>
    <body>
        <title>
            home page
        </title>

     <table border="0" weidth=60%  align="center"   style="background-color: #ffffff; filter: alpha(opacity=40); opacity: 0.95;border:1px green solid;" >
        <tr height="100px" >
            <th width=20% >
                
                <a href="home.php" width="200px" ><img src="pic.png" alt="photo"></a>
            </th>
            <th></th>
            <th width = 20% align="left" >
                <a href="home.php">Home | </a>
                <a href="../views/auth/signin.php">Sign In | </a>
                <a href="../views/auth/signup.php">Sign Up</a>
            </th>

        </tr>
        <tr>
            <td>
                
            </td>
            <td align="center">
                <h3>Welcome to our RH_Company</h3>
                <p>we are happy to see you. we will give you most secure and fast money transfer ever</p>
                <p>let get started,</p>
                <a href="../views/auth/signup.php">Goooooooo</a>
            </td>
            <td></td>
        </tr>

     </table>
     

    </body>
</html>