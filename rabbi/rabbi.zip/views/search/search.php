<!-- <html>

<body>
    <fieldset>
        <legend>
            search
        </legend>
        <table>

            <tr>

                <td> search: <input type="text" name="text" value="">
                </td>
                <td>
                    <form action="">
                        <label for="search">Sort By</label>
                        <select name="search" id="search">
                            <option value="text">default</option>
                            <option value="price-decending">price high to low</option>
                            <option value="price-ascending">price low to high</option>
                        </select>
                    </form> 
                    </td>
                    <td>
                    <form action="">
                        <label for="search">show</label>
                        <select name="input-limit" id="input-limit">
                            <option value="5" selected >5</option>
                            <option value="7">7</option>
                            <option value="10">10</option>
                        </select>
                    </form>
                </td>
            </tr>
            <tr>
                <td>--------------------------------------------------History-------------------------------------------</p>


            <tr>

                <td>
                    <input type="submit" name="submit value="submit">

                </td>
            </tr>

        </table>

    </fieldset>
</body>

</html> -->



<!DOCTYPE html>
<html lang="en">

<head>
    <title>Document</title>
</head>

<body>
    <table border="1" width=70% align="center">
        <tr style="height:50px"" >
        <th width=20%> <a href=" home.php"><img src="../pic.png" alt="logo"  ></a> </th>
            <th width=60%></th>
            <th width=20%>

                <a href="login.php">Logged in as </a> |
                <a href="logout">LogOut</a>

            </th>

        </tr>

        <tr style="height:200px">
            <td> <b>Account</b>
                <hr>
                <ul>
                 <li><a href="../views/dashboard.php">Dashboard</a></li>
                <li><a href="../editprofile/editprofile.php">Edit profile</a></li>
                    <li><a href="search.php">Search</a></li>
                    <li><a href="../offer/offer.php">Offer</a></li>
                    <li><a href="../payment/payment.php">payment</a></li>
            
                    <li><a href="../logout.php">LogOut</a></li>
                </ul>

            </td>
            <td>
                <fieldset>
                    <legend>
                        search
                    </legend>
                    <table>

                        <tr>

                            <td> search: from <input type="date" name="date" value="" placeholder="search by date "> to <input type="date" name="date" value="" placeholder="search by date">

                                <input type="submit" name="submit" value="Enter">

                            </td>
                            <td>
                                <form action="">
                                    <label for="search">Sort By</label>
                                    <select name="search" id="search">
                                        <option value="text">default</option>
                                        <option value="price-decending">price high to low</option>
                                        <option value="price-ascending">price low to high</option>
                                    </select>
                                </form>
                            </td>
                            <td>
                                <form action="">
                                    <label for="search">show</label>
                                    <select name="input-limit" id="input-limit">
                                        <option value="5" selected>5</option>
                                        <option value="7">7</option>
                                        <option value="10">10</option>
                                    </select>
                                </form>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3">
                                <p align="center"> -------------------History---------------------</p>
                            </td>
                        <tr>
                            <td colspan="3">
                                <table>
                                    <tr>
                                        <th>Time</th>
                                        <th>Bank Account Number</th>
                                        <th>Amount</th>
                                    </tr>
                                    <tr>
                                        <td>1:56 PM</td>
                                        <td>BA028088557033198887</td>
                                        <td>$2,144</td>
                                    </tr>
                                    <tr>
                                        <td>10:20 PM</td>
                                        <td>IL574437931197159858668</td>
                                        <td>$9,802</td>
                                    </tr>
                                    <tr>
                                        <td>1:41 PM</td>
                                        <td>SI07612076641027410</td>
                                        <td>$3,758</td>
                                    </tr>
                                    <tr>
                                        <td>8:18 AM</td>
                                        <td>MU3482263823002272703251544676</td>
                                        <td>$2,683</td>
                                    </tr>
                                    <tr>
                                        <td>11:44 PM</td>
                                        <td>DE63158127319727755635</td>
                                        <td>$6,206</td>
                                    </tr>
                                    <tr>
                                        <td>2:54 PM</td>
                                        <td>RS65454692147978215764</td>
                                        <td>$6,968</td>
                                    </tr>
                                    <tr>
                                        <td>10:47 AM</td>
                                        <td>BA196895821322110405</td>
                                        <td>$9,979</td>
                                    </tr>
                                    <tr>
                                        <td>7:41 PM</td>
                                        <td>GI28VENO167713811503586</td>
                                        <td>$4,134</td>
                                    </tr>
                                    <tr>
                                        <td>11:45 AM</td>
                                        <td>LB79633070054712360084485161</td>
                                        <td>$5,690</td>
                                    </tr>
                                    <tr>
                                        <td>11:07 AM</td>
                                        <td>BE38812123773683</td>
                                        <td>$584</td>
                                    </tr>

                                </table>
                            </td>
                        </tr>


                    </table>

                </fieldset>
            </td>


        </tr>

        <tr>
            <td colspan="3" align="center"> coppy right (C) 2017</td>
        </tr>


    </table>

</body>

</html>

<!-- style="height:50px"   -->